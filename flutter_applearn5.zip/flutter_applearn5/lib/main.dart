import 'package:css_colors/css_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:webview_flutter/webview_flutter.dart';

class MyApp extends StatelessWidget {
  InAppWebViewController _webViewController;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Welcome to Flutter',
      home: WillPopScope(
        onWillPop: _onBack,
        child: Scaffold(
          body: InAppWebView(
            initialUrl: "https://www.carrefourjordan.com",
            onWebViewCreated: (InAppWebViewController controller) {
              _webViewController = controller;
            },
          ),
        ),
      ),
    );
  }

  Future<bool> _onBack() async {
    if (await _webViewController.canGoBack()) {
      _webViewController.goBack(); // perform webview back operation
      return false;
    } else {
      // Webpage in home page
      return true; // Close App
    }
  }
}
