package com.example.flutter_applearn5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
